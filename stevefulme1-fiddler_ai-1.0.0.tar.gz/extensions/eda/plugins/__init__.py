"""Ansible collection package."""
